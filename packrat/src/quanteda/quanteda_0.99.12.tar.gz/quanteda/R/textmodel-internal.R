#' internal functions for textmodel objects
#' 
#' Internal function documentation for textmodel objects.
#' @name textmodel-internal
NULL
